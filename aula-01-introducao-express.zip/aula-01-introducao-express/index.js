// IMPORTANDO O EXPRESS
const express = require("express")
// INICIANDO O EXPRESS DENTRO DA VARIÁVEL APP
const app = express()

// Definindo o EJS para renderizar páginas
app.set('view engine', 'ejs')

// Criando a primeira rota do site (ROTA PRINCIPAL)
app.get("/", (req, res) => {
    res.render('index') // Será renderizada a página 'views\index.ejs'
})

// ROTA DE PERFIL
app.get("/perfil/:nome", (req, res) => { // PARÂMETRO OBRIGATÓRIO
    // res.send(req.params.nome) // Coletando o parâmetro
    let nome = req.params.nome
    res.send(`<h2>Olá, ${nome}! Seja muito bem vindo!</h2>`)
})

// ROTA VÍDEOS
app.get("/videos/:playlist/:video", (req, res) => {
    // res.send("<h1 style='text-align: center;'>Essa é a página de vídeos</h1>")
    let playlist = req.params.playlist
    let video = req.params.video
    res.send(`<h2>Você está na playlist de ${playlist}.</h2><br>
    Reproduzindo o vídeo <strong>${video}</strong>...`)
})

app.listen(8080, erro => {
    if(erro){
        console.log("Ocorreu um erro!")
    } else {
        console.log("Servidor iniciado com sucesso!")
    }
})