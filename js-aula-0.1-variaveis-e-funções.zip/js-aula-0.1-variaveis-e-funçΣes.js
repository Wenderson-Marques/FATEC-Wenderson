/* 
Comentário de bloco
*/

// VARIÁVEIS NO JAVASCRIPT
// CONST X VAR X LET
// const nome = "Diego"
// const idade
// let nome = "Diego"
// let nome = "Rodrigo"
// console.log(nome)
// var nome = "Diego"
// var nome = "Renato"
// console.log(nome)
// let idade = 18
// let cidade = "Registro"
// console.log(typeof(idade))
// console.log(typeof(cidade))

/////////////////////////////////////////////
// FUNÇÕES

function minhaFuncao(){

}
// FUNÇÃO SIMPLES
function saudacao(){
    console.log("Olá, bem-vindo!")
}
saudacao()

// FUNÇÃO COM PARÂMETRO / ARGUMENTO
function Saudacao(nome){
    console.log(`Olá, bem-vindo, ${nome}!`)
    // console.log("Olá, bem-vindo, " + nome)
}
Saudacao('Diego')

// FUNÇÃO COM MAIS DE UM PARÂMETRO
function soma(n1, n2){
    let res = n1 + n2
    console.log(`A soma dos dois números foi ${res}`)
}
soma(5, 6)

// FUNÇÃO COM RETORNO
function Soma(n1, n2){
    return n1 + n2
}
// Soma(2, 6)
console.log(`A soma dos dois números foi ${Soma(2,6)}.`)

// FUNÇÃO COM MAIS DE UM RETORNO
function parImpar(n){
    if (n % 2 == 0){
        return 'Par'
    } else {
        return 'Impar'
    }
}
let num = 4
console.log(parImpar(num))
console.log(`O número ${num} é ${parImpar(num)}.`)

// FUNÇÃO ANÔNIMA
let dobro = function(x){
    return x*2
}
console.log(dobro(15))

// ARROW FUNCTION (com único parâmetro)
const Dobro = x => {
    return x*2
}
console.log(`O dobro do número é ${Dobro(20)}.`)

// ARROW FUNCTION (com mais de um parâmetro)
const Calc = (num1, operador, num2) => {
    return eval(`${num1} ${operador} ${num2}`)
}
console.log(`O resultado da operação é ${Calc(6, '*', 6)}.`)

// FUNÇÃO IMEDIATA - IIFE (Immediately Invoked Function Expression)
const iife = (function() {
    console.log("Executando automaticamente!")
})()

const start = (function(app){
    console.log(`Executando imediatamente ${app}.`)
})("Whatsapp")
